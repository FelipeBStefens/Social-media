package socialmedia;

public class Constants {
    
    public static final String IP = "127.0.0.1";
    public static final String DOOR = "3306";
    public static final String USER = "root";
    public static final String PASSWORD = "lipe277279";
    public static final String NAME_DATABASE = "social_media_database";

    public static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    public static final String ADDRESS = "jdbc:mysql://" + IP + ":" + DOOR + "/" + NAME_DATABASE;
}
